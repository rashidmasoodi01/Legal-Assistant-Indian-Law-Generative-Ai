import re
import json
from datetime import datetime
from typing import List, Dict, Any, Optional

class LegalTextProcessor:
    """Utility class for processing legal text and extracting relevant information"""
    
    def __init__(self):
        self.ipc_sections = {
            '302': 'Murder - Punishment for murder',
            '307': 'Attempt to murder',
            '376': 'Rape and sexual offenses',
            '420': 'Cheating and dishonestly inducing delivery of property',
            '498A': 'Husband or relative of husband of a woman subjecting her to cruelty',
            '304': 'Punishment for culpable homicide not amounting to murder',
            '323': 'Punishment for voluntarily causing hurt',
            '325': 'Punishment for voluntarily causing grievous hurt',
            '379': 'Punishment for theft',
            '380': 'Theft in dwelling house, etc.',
            '447': 'Punishment for criminal trespass',
            '506': 'Punishment for criminal intimidation',
            '409': 'Criminal breach of trust by public servant, or by banker, merchant or agent',
            '406': 'Punishment for criminal breach of trust',
            '354': 'Assault or criminal force to woman with intent to outrage her modesty',
            '363': 'Punishment for kidnapping',
            '366': 'Kidnapping, abducting or inducing woman to compel her marriage, etc.',
            '294': 'Obscene acts and songs',
            '156': 'Liability of agent of proprietor of newspaper for defamation',
            '120B': 'Punishment of criminal conspiracy',
            '279': 'Rash driving or riding on a public way',
            '304A': 'Causing death by negligence',
            '338': 'Causing grievous hurt by act endangering life or personal safety of others',
            '337': 'Causing hurt by act endangering life or personal safety of others',
            '341': 'Punishment for wrongful restraint',
            '342': 'Punishment for wrongful confinement'
        }
        
        self.date_patterns = [
            r'\d{1,2}[/-]\d{1,2}[/-]\d{4}',
            r'\d{1,2}[/-]\d{1,2}[/-]\d{2}',
            r'\d{1,2}\s+(January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{4}',
            r'(January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2},?\s+\d{4}',
            r'\d{4}-\d{2}-\d{2}',
            r'\d{2}\.\d{2}\.\d{4}'
        ]

    def extract_ipc_sections(self, text: str) -> List[Dict[str, str]]:
        if not text:
            return []
        
        sections_found = []
        
        ipc_patterns = [
            r'Section\s+(\d+[A-Z]*)\s*(?:of\s+)?(?:Indian\s+Penal\s+Code|IPC|I\.P\.C\.)?',
            r'Sec\.\s*(\d+[A-Z]*)\s*(?:of\s+)?(?:IPC|I\.P\.C\.)?',
            r'(?:IPC|I\.P\.C\.)\s*(?:Section|Sec\.?)\s*(\d+[A-Z]*)',
            r'(\d+[A-Z]*)\s*(?:IPC|I\.P\.C\.)',
            r'u/s\s*(\d+[A-Z]*)',
            r'(?:under|u/s)\s+(?:section|sec\.?)\s*(\d+[A-Z]*)'
        ]
        
        for pattern in ipc_patterns:
            matches = re.finditer(pattern, text, re.IGNORECASE)
            for match in matches:
                section_num = match.group(1).upper()
                description = self.ipc_sections.get(section_num, 'Description not available')
                context = self._extract_context(text, match.start(), match.end())
                
                sections_found.append({
                    'section': section_num,
                    'description': description,
                    'context': context,
                    'position': match.start()
                })
        
        unique_sections = []
        seen_sections = set()
        for section in sections_found:
            if section['section'] not in seen_sections:
                unique_sections.append(section)
                seen_sections.add(section['section'])
        
        return unique_sections

    def _extract_context(self, text: str, start: int, end: int, context_length: int = 100) -> str:
        context_start = max(0, start - context_length)
        context_end = min(len(text), end + context_length)
        context = text[context_start:context_end].strip()
        context = re.sub(r'\s+', ' ', context)
        return context

    def extract_timeline(self, text: str) -> List[Dict[str, str]]:
        if not text:
            return []
        
        timeline_events = []
        
        for pattern in self.date_patterns:
            matches = re.finditer(pattern, text, re.IGNORECASE)
            for match in matches:
                date_str = match.group(0)
                context = self._extract_context(text, match.start(), match.end(), 150)
                event_type = self._classify_timeline_event(context)
                
                timeline_events.append({
                    'date': date_str,
                    'context': context,
                    'event_type': event_type,
                    'position': match.start()
                })
        
        timeline_events.sort(key=lambda x: x['position'])
        unique_events = []
        seen_dates = set()
        for event in timeline_events:
            normalized_date = self._normalize_date(event['date'])
            if normalized_date not in seen_dates:
                unique_events.append({
                    'date': event['date'],
                    'event': event['context'],
                    'event_type': event['event_type'],
                    'normalized_date': normalized_date
                })
                seen_dates.add(normalized_date)
        
        return unique_events[:20]

    def _classify_timeline_event(self, context: str) -> str:
        context_lower = context.lower()
        
        if any(word in context_lower for word in ['filed', 'petition', 'complaint', 'case']):
            return 'filing'
        elif any(word in context_lower for word in ['judgment', 'decided', 'order', 'ruling']):
            return 'decision'
        elif any(word in context_lower for word in ['hearing', 'argument', 'court', 'appearance']):
            return 'hearing'
        elif any(word in context_lower for word in ['appeal', 'revision', 'review']):
            return 'appeal'
        elif any(word in context_lower for word in ['incident', 'occurred', 'happened', 'event']):
            return 'incident'
        else:
            return 'general'

    def _normalize_date(self, date_str: str) -> str:
        date_str = re.sub(r'[^\d\w\s]', '', date_str.lower())
        return date_str.strip()

    def extract_verdict_summary(self, text: str) -> Dict[str, Any]:
        if not text:
            return {}
        
        verdict_info = {
            'disposition': '',
            'key_findings': [],
            'parties': {'petitioner': '', 'respondent': ''},
            'court_decision': '',
            'ratio': '',
            'obiter_dicta': []
        }
        
        verdict_patterns = [
            r'(?:petition|appeal|writ)\s+(?:is\s+)?(dismissed|allowed|partly\s+allowed|quashed|set\s+aside|upheld|confirmed|reversed)',
            r'(?:defendant|accused)\s+(?:is\s+)?(guilty|not\s+guilty|convicted|acquitted)',
            r'(?:application|prayer|relief)\s+(?:is\s+)?(granted|denied|rejected|accepted)',
            r'(?:we|court|this\s+court)\s+(?:hereby\s+)?(allow|dismiss|quash|set\s+aside|uphold|confirm|reverse)',
            r'(?:judgment|order)\s+(?:is\s+)?(allowed|dismissed|modified|confirmed)'
        ]
        
        for pattern in verdict_patterns:
            matches = re.finditer(pattern, text, re.IGNORECASE)
            for match in matches:
                disposition = match.group(1).lower().strip()
                verdict_info['disposition'] = disposition
                verdict_info['court_decision'] = self._extract_context(text, match.start(), match.end(), 200)
                break
        
        finding_patterns = [
            r'[^.]*(?:held|decided|concluded|observed|found|ruled|determined)[^.]*\.',
            r'[^.]*(?:principle|law|rule|doctrine)[^.]*\.',
            r'[^.]*(?:precedent|authority|binding|ratio)[^.]*\.',
            r'[^.]*(?:constitutional|statutory|legal)[^.]*\.',
        ]
        
        findings_set = set()
        for pattern in finding_patterns:
            matches = re.finditer(pattern, text, re.IGNORECASE)
            for match in matches:
                finding = match.group(0).strip()
                if len(finding) > 30 and len(finding) < 500 and finding not in findings_set:
                    verdict_info['key_findings'].append(finding)
                    findings_set.add(finding)
                if len(verdict_info['key_findings']) >= 10:
                    break
        
        return verdict_info

class CaseStorage:
    """Handle saving and loading of bookmarked cases"""
    
    def __init__(self, storage_file='saved_cases.json'):
        self.storage_file = storage_file
        self.cases = self.load_cases()
    
    def load_cases(self) -> List[Dict]:
        try:
            with open(self.storage_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            return []
    
    def save_cases(self):
        try:
            with open(self.storage_file, 'w', encoding='utf-8') as f:
                json.dump(self.cases, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"Error saving cases: {e}")
    
    def add_case(self, case_data: Dict) -> bool:
        try:
            case_data['saved_at'] = datetime.now().isoformat()
            
            for existing_case in self.cases:
                if (existing_case.get('docid') == case_data.get('docid') or 
                    existing_case.get('title') == case_data.get('title')):
                    return False
            
            self.cases.append(case_data)
            self.save_cases()
            return True
        except Exception as e:
            print(f"Error adding case: {e}")
            return False
    
    def remove_case(self, case_index: int) -> bool:
        try:
            if 0 <= case_index < len(self.cases):
                self.cases.pop(case_index)
                self.save_cases()
                return True
            return False
        except Exception as e:
            print(f"Error removing case: {e}")
            return False
    
    def get_cases(self) -> List[Dict]:
        return self.cases