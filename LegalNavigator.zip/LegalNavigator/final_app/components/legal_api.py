import logging
import json
import http.client
import urllib.parse
import requests
import re
import time
import os
import hashlib
from dotenv import load_dotenv
from groq import Groq

load_dotenv(override=True)

INDIANKANOON_API_TOKEN = os.getenv('INDIANKANOON_API_TOKEN')
HUGGINGFACE_API_TOKEN = os.getenv('HUGGINGFACE_API_TOKEN')
API_URL = os.getenv('API_URL')
GROQ_API_KEY = os.getenv('GROQ_API_KEY')

class LegalAPI:
    def __init__(self, maxpages=5):
        self.logger = logging.getLogger('legal_api')
        self.headers = {
            'Authorization': f'Token {INDIANKANOON_API_TOKEN}',
            'Accept': 'application/json',
            'User-Agent': 'Mozilla/5.0'
        }
        self.basehost = 'api.indiankanoon.org'
        self.maxpages = min(maxpages, 100)
        self.huggingface_api_url = API_URL
        self.hf_headers = {
            'Authorization': f'Bearer {HUGGINGFACE_API_TOKEN}'
        }
        self.cache = {}

    def clean_text(self, text):
        if not text:
            return ""
        text = re.sub(r"<[^>]+>", " ", text)
        text = re.sub(r"\s+", " ", text)
        text = re.sub(r"[^\w\s\.,;:\-\(\)\[\]'\"]+", " ", text)
        return text.strip()

    def summarize(self, text, max_length=150, min_length=50):
        if not text or len(text.strip()) < 10:
            return "Text too short to summarize"
        
        cleaned_text = self.clean_text(text)
        truncated_text = cleaned_text[:2000]

        key_hash = hashlib.sha256(truncated_text.encode('utf-8')).hexdigest()
        cache_key = f"{key_hash}_{max_length}_{min_length}"

        if cache_key in self.cache:
            return self.cache[cache_key]

        payload = {
            "inputs": truncated_text,
            "parameters": {
                "max_length": max_length, 
                "min_length": min_length, 
                "truncation": True,
                "do_sample": False
            }
        }

        try:
            response = requests.post(
                self.huggingface_api_url,
                headers=self.hf_headers,
                json=payload,
                timeout=30
            )

            if response.status_code == 503:
                error_data = response.json() if response.content else {}
                eta = error_data.get("estimated_time", 20)
                if eta < 60:
                    time.sleep(min(eta, 30))
                    return self.summarize(text, max_length, min_length)
                else:
                    result = self._fallback_summary(truncated_text, max_length)
            elif response.status_code == 200:
                data = response.json()
                if isinstance(data, list) and len(data) > 0 and "summary_text" in data[0]:
                    result = data[0]["summary_text"]
                elif isinstance(data, dict) and "summary_text" in data:
                    result = data["summary_text"]
                else:
                    result = self._fallback_summary(truncated_text, max_length)
            else:
                result = self._fallback_summary(truncated_text, max_length)
                
        except Exception as e:
            self.logger.error(f"Exception during summarization: {e}")
            result = self._fallback_summary(truncated_text, max_length)

        self.cache[cache_key] = result
        return result

    def _fallback_summary(self, text, max_length=150):
        sentences = re.split(r'[.!?]+', text)
        summary_sentences = []
        total_length = 0
        
        for sentence in sentences:
            if total_length + len(sentence) < max_length and len(summary_sentences) < 3:
                summary_sentences.append(sentence.strip())
                total_length += len(sentence)
            else:
                break
        
        result = '. '.join(summary_sentences)
        return result if result else text[:max_length] + "..."

    def fetch_doc(self, docid):
        if not docid:
            return None
        
        url = f'/doc/{docid}/'
        try:
            connection = http.client.HTTPSConnection(self.basehost, timeout=30)
            connection.request("POST", url, headers=self.headers)
            response = connection.getresponse()
            
            if response.status != 200:
                self.logger.warning(f"Failed to fetch document {docid}. HTTP {response.status}: {response.reason}")
                return None
            
            data = response.read()
            connection.close()
            return json.loads(data)
            
        except Exception as e:
            self.logger.error(f"Error fetching document {docid}: {e}")
            return None

    def fetch_all_docs(self, query, filters=None):
        if not query or not query.strip():
            return []
        
        doc_ids = []
        pagenum = 0
        
        search_query = query.strip()
        if filters:
            if filters.get('court'):
                search_query += f" court:\"{filters['court']}\""
            if filters.get('judge'):
                search_query += f" judge:\"{filters['judge']}\""
            if filters.get('ipc_section'):
                search_query += f" section {filters['ipc_section']}"
        
        consecutive_failures = 0
        max_failures = 3
        
        while pagenum < self.maxpages and consecutive_failures < max_failures:
            try:
                encoded_query = urllib.parse.quote_plus(search_query)
                url = f'/search/?formInput={encoded_query}&pagenum={pagenum}&maxpages=1'
                results = self.call_api(url)
                
                if not results:
                    consecutive_failures += 1
                    pagenum += 1
                    continue
                
                try:
                    obj = json.loads(results)
                except json.JSONDecodeError as e:
                    consecutive_failures += 1
                    pagenum += 1
                    continue
                
                if 'docs' not in obj or not obj['docs']:
                    break
                
                page_doc_count = 0
                for doc in obj['docs']:
                    docid = doc.get('tid')
                    if docid and docid not in doc_ids:
                        doc_ids.append(docid)
                        page_doc_count += 1
                
                if page_doc_count == 0:
                    consecutive_failures += 1
                else:
                    consecutive_failures = 0
                
                pagenum += 1
                
            except Exception as e:
                self.logger.error(f"Error on page {pagenum}: {e}")
                consecutive_failures += 1
                pagenum += 1
        
        return doc_ids

    def call_api(self, url):
        try:
            connection = http.client.HTTPSConnection(self.basehost, timeout=30)
            connection.request('POST', url, headers=self.headers)
            response = connection.getresponse()
            
            if response.status == 200:
                data = response.read()
                connection.close()
                return data
            else:
                connection.close()
                return None
                
        except Exception as e:
            self.logger.error(f"Exception during API call: {e}")
            return None

    def extract_case_metadata(self, case_details):
        if not case_details:
            return {}
        
        title = case_details.get("title", "")
        doc_text = case_details.get("doc", "")
        
        metadata = {
            'title': title,
            'petitioner': '',
            'respondent': '',
            'court': '',
            'judge': '',
            'date': '',
            'citation': case_details.get('citation', ''),
            'bench': case_details.get('bench', ''),
            'url': case_details.get('url', ''),
            'docid': case_details.get('tid', '')
        }
        
        party_patterns = [
            r'(.+?)\s+(?:vs\.?|v\.?)\s+(.+?)(?:\s+on\s+|\s+decided\s+|\s+dated\s+|$)',
            r'(.+?)\s+v\.?\s+(.+?)(?:\s+\(|\s+on\s+|\s+decided\s+|\s+dated\s+|$)',
            r'(.+?)\s+vs\s+(.+?)(?:\s+\(|\s+on\s+|\s+decided\s+|\s+dated\s+|$)'
        ]
        
        for pattern in party_patterns:
            match = re.search(pattern, title, re.IGNORECASE)
            if match:
                metadata['petitioner'] = match.group(1).strip()
                metadata['respondent'] = match.group(2).strip()
                break
        
        court_patterns = [
            r'(Supreme Court of India)',
            r'(High Court of [A-Za-z\s]+)',
            r'([A-Za-z\s]+High Court)',
            r'(Supreme Court)',
            r'(High Court)',
            r'(District Court)',
            r'(Sessions Court)',
            r'(Magistrate Court)'
        ]
        
        for pattern in court_patterns:
            match = re.search(pattern, doc_text, re.IGNORECASE)
            if match:
                metadata['court'] = match.group(1)
                break
        
        return metadata

    def query_ai_model(self, question, related_case_summaries):
        if not question or not related_case_summaries:
            return "Error: Missing question or case summaries"
        
        try:
            client = Groq(api_key=GROQ_API_KEY)

            max_summary_length = 3000
            if len(related_case_summaries) > max_summary_length:
                related_case_summaries = related_case_summaries[:max_summary_length] + "...[truncated]"

            messages = [
                {
                    "role": "system",
                    "content": (
                        "You are an expert legal AI assistant with deep knowledge of Indian law and jurisprudence. "
                        "Your task is to provide comprehensive legal analysis based on case summaries provided. "
                        "Focus on extracting key legal principles, precedents, and providing actionable insights. "
                        "Always maintain objectivity and cite relevant case law when possible."
                    ),
                },
                {
                    "role": "user",
                    "content": (
                        f"Query: {question}\n\n"
                        "Related case summaries:\n\n"
                        + related_case_summaries
                    ),
                },
            ]

            completion = client.chat.completions.create(
                model="llama3-8b-8192",
                messages=messages,
                temperature=0.7,
                max_tokens=1000,
                top_p=0.95,
                stream=True,
                stop=None,
            )

            answer = ""
            for chunk in completion:
                delta = chunk.choices[0].delta.content or ""
                answer += delta

            return answer.strip()

        except Exception as e:
            return f"Error while querying AI: {str(e)}"