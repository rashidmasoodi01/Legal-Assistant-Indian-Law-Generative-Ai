import streamlit as st
import json
import re
import hashlib
from datetime import datetime
from typing import Dict, List, Any
import os
from dotenv import load_dotenv
from components.legal_api import LegalAPI
from components.legal_utils import LegalTextProcessor, CaseStorage
from database.legal_database import LegalDatabase
from assets.images import ImageManager
from assets.styles import StyleManager
import plotly.express as px
import plotly.graph_objects as go

# Load environment variables
load_dotenv()

# Page configuration
st.set_page_config(
    page_title="Legal Assistant Pro",
    page_icon="⚖️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Initialize session state with database integration
if 'session_id' not in st.session_state:
    st.session_state.session_id = hashlib.md5(str(datetime.now()).encode()).hexdigest()[:12]

if 'legal_api' not in st.session_state:
    st.session_state.legal_api = LegalAPI(maxpages=5)

if 'legal_db' not in st.session_state:
    st.session_state.legal_db = LegalDatabase()

if 'legal_processor' not in st.session_state:
    st.session_state.legal_processor = LegalTextProcessor()

if 'image_manager' not in st.session_state:
    st.session_state.image_manager = ImageManager()

if 'style_manager' not in st.session_state:
    st.session_state.style_manager = StyleManager()

if 'user_mode' not in st.session_state:
    st.session_state.user_mode = "Student"

if 'current_cases' not in st.session_state:
    st.session_state.current_cases = []

if 'comparison_cases' not in st.session_state:
    st.session_state.comparison_cases = []

# Apply dynamic styling
st.session_state.style_manager.apply_mode_styling(st.session_state.user_mode)

# Helper functions
def calculate_relevance_score(text, query):
    text_lower = text.lower()
    query_lower = query.lower()
    query_words = query_lower.split()
    
    score = 0
    for word in query_words:
        if word in text_lower:
            score += text_lower.count(word)
    
    return score / len(query_words) if query_words else 0

def generate_case_insights(case_data):
    insights = []
    
    ipc_sections = case_data.get('ipc_sections', [])
    if ipc_sections:
        if len(ipc_sections) == 1:
            insights.append(f"Single IPC section case involving Section {ipc_sections[0]['section']}")
        else:
            insights.append(f"Complex case involving {len(ipc_sections)} IPC sections")
    
    court = case_data.get('metadata', {}).get('court', '')
    if 'Supreme Court' in court:
        insights.append("Supreme Court case - precedent setting")
    elif 'High Court' in court:
        insights.append("High Court case - significant jurisdiction")
    
    timeline = case_data.get('timeline', [])
    if len(timeline) > 5:
        insights.append("Extended legal proceedings")
    elif len(timeline) > 0:
        insights.append(f"Timeline spans {len(timeline)} key events")
    
    verdict = case_data.get('verdict', {})
    if verdict.get('disposition'):
        insights.append(f"Concluded with {verdict['disposition']}")
    
    return insights[:5]

def get_mode_specific_features(mode):
    mode_configs = {
        "Student": {
            'title': "Legal Research Assistant - Student Mode",
            'description': "Academic legal research with educational focus",
            'color': "#1e3a8a",
            'features': ["Case Study Analysis", "Legal Principle Extraction", "Academic Citations", "Research Reports"],
            'search_suggestions': [
                "constitutional law principles",
                "criminal law case studies", 
                "civil rights judgments",
                "contract law precedents",
                "tort law examples",
                "evidence law cases",
                "procedural law judgments"
            ]
        },
        "Lawyer": {
            'title': "Professional Legal Research - Lawyer Mode", 
            'description': "Strategic case analysis and precedent research",
            'color': "#166534",
            'features': ["Precedent Analysis", "Case Strategy", "Client Brief Generation", "Legal Argument Building"],
            'search_suggestions': [
                "similar fact patterns",
                "successful defense strategies",
                "appeal court decisions",
                "settlement precedents",
                "evidence admissibility",
                "bail application cases",
                "cross-examination tactics"
            ]
        },
        "Judge": {
            'title': "Judicial Research Platform - Judge Mode",
            'description': "Comprehensive jurisprudential analysis",
            'color': "#991b1b",
            'features': ["Precedent Compilation", "Legal Framework Analysis", "Jurisdictional Comparison", "Sentencing Guidelines"],
            'search_suggestions': [
                "sentencing guidelines",
                "jurisdictional precedents",
                "constitutional interpretation",
                "judicial review cases",
                "procedural law decisions",
                "precedent authority",
                "binding vs persuasive"
            ]
        },
        "General": {
            'title': "Legal Assistance Platform - General Mode",
            'description': "General legal information and guidance",
            'color': "#6b7280",
            'features': ["Basic Legal Info", "Case Summaries", "Legal Procedures", "Rights Information"],
            'search_suggestions': [
                "legal procedures",
                "citizen rights",
                "court procedures",
                "legal documentation",
                "dispute resolution",
                "consumer rights",
                "family law basics"
            ]
        }
    }
    return mode_configs.get(mode, mode_configs["General"])

def display_mode_badge(mode: str):
    mode_icons = {
        "Student": "🎓",
        "Lawyer": "⚖️",
        "Judge": "👨‍⚖️",
        "General": "👤"
    }
    
    icon = mode_icons.get(mode, "👤")
    color = st.session_state.style_manager.get_mode_color(mode)
    
    st.markdown(f"""
    <div style="
        background-color: {color}; 
        color: white; 
        padding: 8px 16px; 
        border-radius: 20px; 
        text-align: center; 
        font-weight: bold;
        margin: 10px 0;
    ">
        {icon} {mode} Mode
    </div>
    """, unsafe_allow_html=True)

def legal_search_page(mode_config):
    st.header("🔍 Legal Case Search with Database Integration")
    
    # Quick suggestions
    st.write("**Quick Search Suggestions:**")
    cols = st.columns(3)
    for i, suggestion in enumerate(mode_config['search_suggestions'][:6]):
        col_idx = i % 3
        with cols[col_idx]:
            if st.button(suggestion, key=f"suggest_{i}", use_container_width=True):
                st.session_state.search_query = suggestion
    
    # Search form
    with st.form("search_form"):
        query = st.text_input("Enter your legal query:", 
                            value=st.session_state.get('search_query', ''),
                            placeholder="e.g., road accident negligence cases")
        
        col1, col2 = st.columns(2)
        
        with col1:
            search_location = st.radio("Search in:", ["Indian Kanoon API", "Local Database", "Both"])
        
        with col2:
            sort_by = st.selectbox("Sort by:", ["Relevance", "Date", "Court Level"])
        
        # Advanced filters
        with st.expander("🔍 Advanced Search Filters"):
            col1, col2, col3 = st.columns(3)
            
            with col1:
                court_filter = st.selectbox("Court", 
                    ["All Courts", "Supreme Court", "High Court", "District Court"])
                date_from = st.date_input("From Date", value=None)
            
            with col2:
                judge_filter = st.text_input("Judge Name")
                date_to = st.date_input("To Date", value=None)
            
            with col3:
                ipc_section = st.text_input("IPC Section")
                max_results = st.slider("Max Results", 5, 50, 20)
        
        search_submitted = st.form_submit_button("🔍 Search Cases", type="primary")
    
    if search_submitted and query:
        with st.spinner("Searching legal cases..."):
            # Build filters
            filters = {}
            if court_filter != "All Courts":
                filters['court'] = court_filter
            if judge_filter:
                filters['judge'] = judge_filter
            if ipc_section:
                filters['ipc_section'] = ipc_section
            
            all_cases = []
            
            # Search in Indian Kanoon API
            if search_location in ["Indian Kanoon API", "Both"]:
                try:
                    doc_ids = st.session_state.legal_api.fetch_all_docs(query, filters)
                    
                    if doc_ids:
                        st.success(f"Found {len(doc_ids)} cases from Indian Kanoon")
                        
                        progress_bar = st.progress(0)
                        
                        for i, doc_id in enumerate(doc_ids[:max_results]):
                            case_details = st.session_state.legal_api.fetch_doc(doc_id)
                            if case_details:
                                case_data = process_case_data(case_details, query)
                                all_cases.append(case_data)
                                
                                # Save to database
                                st.session_state.legal_db.save_case(case_data)
                            
                            progress_bar.progress((i + 1) / min(len(doc_ids), max_results))
                        
                        progress_bar.empty()
                    
                except Exception as e:
                    st.error(f"Error accessing Indian Kanoon API: {str(e)}")
            
            # Search in local database
            if search_location in ["Local Database", "Both"]:
                try:
                    db_cases = st.session_state.legal_db.search_cases_in_db(query, filters, max_results)
                    if db_cases:
                        all_cases.extend(db_cases)
                        st.success(f"Found {len(db_cases)} cases in local database")
                except Exception as e:
                    st.error(f"Error searching database: {str(e)}")
            
            if all_cases:
                # Save search history
                st.session_state.legal_db.save_search_history(
                    query, st.session_state.user_mode, filters, 
                    len(all_cases), st.session_state.session_id
                )
                
                # Store in session state
                st.session_state.current_cases = all_cases
                
                # Display results
                display_search_results(all_cases, mode_config)
            else:
                st.warning("No cases found for your query. Try different keywords or filters.")

def process_case_data(case_details, query):
    title = case_details.get("title", "Untitled Case")
    main_text = case_details.get("doc", "")
    
    # Clean and summarize text
    cleaned_text = st.session_state.legal_api.clean_text(main_text)
    summary = st.session_state.legal_api.summarize(cleaned_text[:3000])
    
    # Extract metadata
    metadata = st.session_state.legal_api.extract_case_metadata(case_details)
    
    # Extract IPC sections and timeline
    ipc_sections = st.session_state.legal_processor.extract_ipc_sections(main_text)
    timeline = st.session_state.legal_processor.extract_timeline(main_text)
    verdict = st.session_state.legal_processor.extract_verdict_summary(main_text)
    
    # Calculate relevance
    relevance_score = calculate_relevance_score(cleaned_text, query)
    
    return {
        'docid': case_details.get('tid', ''),
        'title': title,
        'summary': summary,
        'metadata': metadata,
        'ipc_sections': ipc_sections,
        'timeline': timeline,
        'verdict': verdict,
        'relevance_score': relevance_score,
        'full_text': cleaned_text,
        'insights': generate_case_insights({
            'ipc_sections': ipc_sections,
            'metadata': metadata,
            'timeline': timeline,
            'verdict': verdict
        })
    }

def display_search_results(cases, mode_config):
    if not cases:
        st.info("No cases found.")
        return
    
    # Sort by relevance
    cases.sort(key=lambda x: x['relevance_score'], reverse=True)
    
    # Results summary
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Total Cases", len(cases))
    with col2:
        avg_relevance = sum(case['relevance_score'] for case in cases) / len(cases)
        st.metric("Avg Relevance", f"{avg_relevance:.2f}")
    with col3:
        total_sections = len(set(section['section'] for case in cases 
                               for section in case.get('ipc_sections', [])))
        st.metric("IPC Sections", total_sections)
    with col4:
        court_types = len(set(case.get('metadata', {}).get('court', '') for case in cases))
        st.metric("Court Types", court_types)
    
    # Export options
    with st.expander("📥 Export Results"):
        col1, col2 = st.columns(2)
        with col1:
            if st.button("📄 Download as JSON"):
                json_data = json.dumps(cases, indent=2, ensure_ascii=False, default=str)
                st.download_button(
                    label="Download JSON",
                    data=json_data,
                    file_name=f"search_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
                    mime="application/json"
                )
        with col2:
            if st.button("📊 Generate Analysis Report"):
                st.info("AI-powered analysis report functionality integrated with database.")
    
    # Display cases
    for i, case in enumerate(cases):
        with st.expander(f"📋 {case['title'][:100]}{'...' if len(case['title']) > 100 else ''}", expanded=(i == 0)):
            col1, col2 = st.columns([2, 1])
            
            with col1:
                st.write("**Summary:**")
                st.write(case['summary'])
                
                if case['ipc_sections']:
                    st.write("**IPC Sections:**")
                    for section in case['ipc_sections'][:5]:
                        st.write(f"• Section {section['section']}: {section['description']}")
                
                if case['timeline']:
                    st.write("**Key Timeline Events:**")
                    for event in case['timeline'][:3]:
                        st.write(f"• {event['date']}: {event['event'][:100]}...")
                
                if case['verdict'].get('disposition'):
                    st.write(f"**Decision:** {case['verdict']['disposition']}")
            
            with col2:
                st.metric("Relevance Score", f"{case['relevance_score']:.2f}")
                
                if case['metadata'].get('court'):
                    st.write(f"**Court:** {case['metadata']['court']}")
                
                if case['metadata'].get('petitioner'):
                    st.write(f"**Petitioner:** {case['metadata']['petitioner'][:30]}...")
                
                if case['metadata'].get('respondent'):
                    st.write(f"**Respondent:** {case['metadata']['respondent'][:30]}...")
                
                # Database action buttons
                col1_btn, col2_btn = st.columns(2)
                with col1_btn:
                    if st.button("💾 Bookmark", key=f"bookmark_{i}"):
                        try:
                            # Save case to database if not already there
                            case_id = st.session_state.legal_db.save_case(case)
                            # Bookmark the case
                            st.session_state.legal_db.bookmark_case(case_id, st.session_state.session_id)
                            st.success("Case bookmarked!")
                        except Exception as e:
                            st.error(f"Error bookmarking case: {str(e)}")
                
                with col2_btn:
                    if st.button("⚖️ Compare", key=f"compare_{i}"):
                        if len(st.session_state.comparison_cases) < 2:
                            st.session_state.comparison_cases.append(case)
                            st.success(f"Added to comparison ({len(st.session_state.comparison_cases)}/2)")
                        else:
                            st.info("Comparison limit reached (2 cases)")
            
            # Case insights
            if case.get('insights'):
                st.write("**AI Insights:**")
                for insight in case['insights']:
                    st.write(f"• {insight}")

def document_generator_page(mode_config):
    st.header("📄 AI-Powered Document Generator")
    
    with st.form("doc_generator_form"):
        col1, col2 = st.columns(2)
        
        with col1:
            doc_type = st.selectbox("Document Type", [
                "Legal Brief", "Research Report", "Case Summary", 
                "Legal Memo", "Contract Draft", "Legal Notice",
                "Case Analysis", "Precedent Summary"
            ])
            
            client_name = st.text_input("Client/Matter Name")
            matter_type = st.text_input("Matter Type")
        
        with col2:
            urgency = st.selectbox("Urgency Level", ["Low", "Medium", "High", "Critical"])
            jurisdiction = st.text_input("Jurisdiction")
        
        requirements = st.text_area("Document Requirements", 
                                  placeholder="Describe what you need in the document...",
                                  height=150)
        
        # Document options
        with st.expander("Advanced Options"):
            col1, col2 = st.columns(2)
            with col1:
                include_precedents = st.checkbox("Include Precedent Analysis", value=True)
                include_citations = st.checkbox("Include Legal Citations", value=True)
            with col2:
                include_arguments = st.checkbox("Include Legal Arguments", value=True)
                use_db_cases = st.checkbox("Use Database Cases as Reference", value=False)
        
        generate_doc = st.form_submit_button("📝 Generate Document", type="primary")
    
    if generate_doc and requirements:
        with st.spinner("Generating AI-powered legal document..."):
            try:
                # Prepare context from database cases if requested
                case_context = ""
                if use_db_cases and st.session_state.current_cases:
                    case_summaries = []
                    for case in st.session_state.current_cases[:5]:
                        case_summaries.append(f"Case: {case.get('title', 'Unknown')}\nSummary: {case.get('summary', '')}")
                    case_context = "\n\n".join(case_summaries)
                
                # Generate document using AI
                case_law_section = f"Relevant Case Law:\n{case_context}" if case_context else ""
                prompt = f"""
                Document Type: {doc_type}
                Client/Matter: {client_name} - {matter_type}
                Jurisdiction: {jurisdiction}
                Urgency: {urgency}
                
                Requirements: {requirements}
                
                {case_law_section}
                
                Please create a professional {doc_type} addressing all requirements.
                """
                
                # Use AI for document generation
                generated_content = st.session_state.legal_api.query_ai_model(
                    f"Generate a professional {doc_type} based on the following requirements",
                    prompt
                )
                
                # Save generated document to database
                doc_data = {
                    'document_type': doc_type,
                    'title': f"{doc_type} - {client_name}",
                    'content': generated_content,
                    'client_name': client_name,
                    'matter_type': matter_type,
                    'jurisdiction': jurisdiction,
                    'urgency_level': urgency,
                    'referenced_cases': [case.get('docid', '') for case in st.session_state.current_cases[:5]] if use_db_cases else [],
                    'generation_parameters': {
                        'include_precedents': include_precedents,
                        'include_citations': include_citations,
                        'include_arguments': include_arguments,
                        'use_db_cases': use_db_cases
                    },
                    'user_session': st.session_state.session_id
                }
                
                doc_id = st.session_state.legal_db.save_generated_document(doc_data)
                
                st.success(f"Document generated and saved to database (ID: {doc_id})")
                
                # Display generated document
                st.subheader("Generated Document")
                st.markdown(f"**Document Type:** {doc_type}")
                st.markdown(f"**Generated:** {datetime.now().strftime('%B %d, %Y at %I:%M %p')}")
                st.divider()
                
                st.write(generated_content)
                
                # Download options
                st.divider()
                col1, col2 = st.columns(2)
                with col1:
                    st.download_button(
                        label="📄 Download as Text",
                        data=generated_content,
                        file_name=f"{doc_type.lower().replace(' ', '_')}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt",
                        mime="text/plain"
                    )
                
                with col2:
                    formatted_doc = f"""# {doc_type}

**Client/Matter:** {client_name} - {matter_type}
**Jurisdiction:** {jurisdiction}
**Generated:** {datetime.now().strftime('%B %d, %Y at %I:%M %p')}

---

{generated_content}

---

*Generated by Legal Assistant Pro with Database Integration*
"""
                    st.download_button(
                        label="📝 Download Formatted",
                        data=formatted_doc,
                        file_name=f"{doc_type.lower().replace(' ', '_')}_formatted_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md",
                        mime="text/markdown"
                    )
                
            except Exception as e:
                st.error(f"Error generating document: {str(e)}")

def case_library_page(mode_config):
    st.header("📚 Enhanced Case Library with Database")
    
    tabs = st.tabs(["Bookmarked Cases", "Search History", "Analytics", "Database Stats"])
    
    with tabs[0]:
        st.subheader("Your Bookmarked Cases")
        try:
            bookmarked_cases = st.session_state.legal_db.get_bookmarked_cases(st.session_state.session_id)
            
            if bookmarked_cases:
                for i, case in enumerate(bookmarked_cases):
                    with st.expander(f"📋 {case.get('title', 'Untitled')[:80]}..."):
                        col1, col2 = st.columns([3, 1])
                        
                        with col1:
                            st.write(f"**Summary:** {case.get('summary', 'No summary')[:200]}...")
                            st.write(f"**Court:** {case.get('metadata', {}).get('court', 'Unknown')}")
                            st.write(f"**Bookmarked:** {case.get('bookmarked_at', 'Unknown')[:10]}")
                            if case.get('bookmark_notes'):
                                st.write(f"**Notes:** {case['bookmark_notes']}")
                        
                        with col2:
                            if st.button("🗑️ Remove", key=f"remove_bookmark_{i}"):
                                st.info("Bookmark removal functionality integrated with database")
            else:
                st.info("No bookmarked cases yet. Search and bookmark cases to build your library.")
        except Exception as e:
            st.error(f"Error loading bookmarked cases: {str(e)}")
    
    with tabs[1]:
        st.subheader("Search History from Database")
        try:
            search_history = st.session_state.legal_db.get_search_history(st.session_state.session_id, 20)
            
            if search_history:
                for search in search_history:
                    col1, col2, col3, col4 = st.columns([3, 1, 1, 1])
                    
                    with col1:
                        st.write(f"**{search['query'][:50]}{'...' if len(search['query']) > 50 else ''}**")
                    with col2:
                        st.write(search['user_mode'])
                    with col3:
                        st.write(f"{search['results_count']} results")
                    with col4:
                        st.write(search['search_timestamp'][:10])
            else:
                st.info("No search history found.")
        except Exception as e:
            st.error(f"Error loading search history: {str(e)}")
    
    with tabs[2]:
        st.subheader("Analytics from Database")
        try:
            analytics = st.session_state.legal_db.get_analytics_data(st.session_state.session_id)
            
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Total Cases in DB", analytics['total_cases'])
            with col2:
                st.metric("Your Searches", analytics['total_searches'])
            with col3:
                st.metric("Session ID", st.session_state.session_id[:8] + "...")
            
            # Top IPC sections chart
            if analytics['top_ipc_sections']:
                fig = px.bar(
                    x=[s['section'] for s in analytics['top_ipc_sections']],
                    y=[s['count'] for s in analytics['top_ipc_sections']],
                    title="Most Common IPC Sections in Database"
                )
                st.plotly_chart(fig, use_container_width=True)
            
            # Court distribution
            if analytics['court_distribution']:
                fig = px.pie(
                    values=[c['count'] for c in analytics['court_distribution']],
                    names=[c['court'] for c in analytics['court_distribution']],
                    title="Cases by Court in Database"
                )
                st.plotly_chart(fig, use_container_width=True)
                
        except Exception as e:
            st.error(f"Error loading analytics: {str(e)}")
    
    with tabs[3]:
        st.subheader("Database Statistics")
        try:
            db_stats = st.session_state.legal_db.get_database_stats()
            
            col1, col2, col3, col4 = st.columns(4)
            with col1:
                st.metric("Cases", db_stats.get('cases_count', 0))
            with col2:
                st.metric("Searches", db_stats.get('search_history_count', 0))
            with col3:
                st.metric("Bookmarks", db_stats.get('saved_cases_count', 0))
            with col4:
                st.metric("Documents", db_stats.get('generated_documents_count', 0))
            
            st.write(f"**Database Size:** {db_stats.get('database_size_mb', 0)} MB")
            
        except Exception as e:
            st.error(f"Error loading database stats: {str(e)}")

def analytics_page(mode_config):
    st.header("📊 Advanced Analytics Dashboard")
    
    try:
        analytics = st.session_state.legal_db.get_analytics_data(st.session_state.session_id)
        
        # Overview metrics
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("Database Cases", analytics['total_cases'])
        with col2:
            st.metric("Your Searches", analytics['total_searches'])
        with col3:
            st.metric("Current Mode", st.session_state.user_mode)
        with col4:
            st.metric("Session Cases", len(st.session_state.current_cases))
        
        # Charts
        if analytics['top_ipc_sections']:
            st.subheader("Top IPC Sections in Database")
            fig = px.bar(
                x=[f"Sec {s['section']}" for s in analytics['top_ipc_sections']],
                y=[s['count'] for s in analytics['top_ipc_sections']],
                title="Most Referenced IPC Sections"
            )
            st.plotly_chart(fig, use_container_width=True)
        
        if analytics['court_distribution']:
            st.subheader("Court Distribution")
            fig = px.pie(
                values=[c['count'] for c in analytics['court_distribution']],
                names=[c['court'] for c in analytics['court_distribution']],
                title="Cases by Court Level"
            )
            st.plotly_chart(fig, use_container_width=True)
        
    except Exception as e:
        st.error(f"Error loading analytics: {str(e)}")

def settings_page(mode_config):
    st.header("⚙️ Settings & Database Management")
    
    # API Status Check
    st.subheader("API Configuration Status")
    
    api_status = {}
    api_status['Indian Kanoon'] = bool(os.getenv('INDIANKANOON_API_TOKEN'))
    api_status['Groq AI'] = bool(os.getenv('GROQ_API_KEY'))
    api_status['Hugging Face'] = bool(os.getenv('HUGGINGFACE_API_TOKEN'))
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        status = "✅ Connected" if api_status['Indian Kanoon'] else "❌ Not configured"
        st.metric("Indian Kanoon API", status)
    
    with col2:
        status = "✅ Connected" if api_status['Groq AI'] else "❌ Not configured"
        st.metric("Groq AI API", status)
    
    with col3:
        status = "✅ Connected" if api_status['Hugging Face'] else "❌ Not configured"
        st.metric("Hugging Face API", status)
    
    # Database Management
    st.subheader("Database Management")
    
    try:
        db_stats = st.session_state.legal_db.get_database_stats()
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.write("**Database Information:**")
            st.write(f"Cases: {db_stats.get('cases_count', 0)}")
            st.write(f"Search History: {db_stats.get('search_history_count', 0)}")
            st.write(f"Bookmarks: {db_stats.get('saved_cases_count', 0)}")
            st.write(f"Generated Documents: {db_stats.get('generated_documents_count', 0)}")
            st.write(f"Database Size: {db_stats.get('database_size_mb', 0)} MB")
        
        with col2:
            if st.button("🧹 Cleanup Old Data"):
                try:
                    cleaned = st.session_state.legal_db.cleanup_old_data(30)
                    st.success(f"Cleaned {cleaned} old records")
                except Exception as e:
                    st.error(f"Cleanup failed: {str(e)}")
            
            if st.button("💾 Backup Database"):
                try:
                    backup_path = f"backup_legal_db_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
                    success = st.session_state.legal_db.backup_database(backup_path)
                    if success:
                        st.success(f"Database backed up to {backup_path}")
                    else:
                        st.error("Backup failed")
                except Exception as e:
                    st.error(f"Backup error: {str(e)}")
    
    except Exception as e:
        st.error(f"Error loading database information: {str(e)}")
    
    # Session Information
    st.subheader("Session Information")
    st.write(f"**Session ID:** {st.session_state.session_id}")
    st.write(f"**Current Mode:** {st.session_state.user_mode}")
    st.write(f"**Cases in Session:** {len(st.session_state.current_cases)}")
    st.write(f"**Comparison Queue:** {len(st.session_state.comparison_cases)}")

def main():
    # Display background image
    st.session_state.image_manager.display_background(st.session_state.user_mode)
    
    # Sidebar for mode selection and navigation
    with st.sidebar:
        st.title("⚖️ Legal Assistant Pro")
        st.caption("With Database Integration")
        
        # Mode selection
        mode_options = ["Student", "Lawyer", "Judge", "General"]
        selected_mode = st.selectbox(
            "Select User Mode",
            mode_options,
            index=mode_options.index(st.session_state.user_mode)
        )
        
        if selected_mode != st.session_state.user_mode:
            st.session_state.user_mode = selected_mode
            st.rerun()
        
        st.divider()
        
        # Navigation menu
        navigation = st.radio(
            "Navigation",
            ["Legal Search", "Document Generator", "Case Library", "Analytics", "Settings"]
        )
        
        # Quick stats in sidebar
        st.divider()
        st.subheader("Quick Stats")
        try:
            db_stats = st.session_state.legal_db.get_database_stats()
            st.write(f"📊 DB Cases: {db_stats.get('cases_count', 0)}")
            st.write(f"💾 Session: {st.session_state.session_id[:8]}...")
            st.write(f"⚖️ Comparing: {len(st.session_state.comparison_cases)}")
        except:
            st.write("📊 Loading stats...")
    
    # Get current mode configuration
    mode_config = get_mode_specific_features(st.session_state.user_mode)
    
    # Main content area
    col1, col2 = st.columns([3, 1])
    
    with col1:
        st.title(mode_config['title'])
        st.write(mode_config['description'])
    
    with col2:
        display_mode_badge(st.session_state.user_mode)
    
    # Route to different pages
    if navigation == "Legal Search":
        legal_search_page(mode_config)
    elif navigation == "Document Generator":
        document_generator_page(mode_config)
    elif navigation == "Case Library":
        case_library_page(mode_config)
    elif navigation == "Analytics":
        analytics_page(mode_config)
    elif navigation == "Settings":
        settings_page(mode_config)

if __name__ == "__main__":
    main()