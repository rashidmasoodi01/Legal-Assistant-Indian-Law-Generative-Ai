import sqlite3
import json
import hashlib
from datetime import datetime
from typing import List, Dict, Any, Optional
from pathlib import Path

class LegalDatabase:
    """Comprehensive database system for Legal Assistant Pro"""
    
    def __init__(self, db_path: str = "legal_assistant.db"):
        self.db_path = db_path
        self.init_database()
    
    def init_database(self):
        """Initialize database with all required tables"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Cases table - stores legal case information
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS cases (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    docid TEXT UNIQUE,
                    title TEXT NOT NULL,
                    summary TEXT,
                    full_text TEXT,
                    court TEXT,
                    judge TEXT,
                    petitioner TEXT,
                    respondent TEXT,
                    date_decided TEXT,
                    citation TEXT,
                    bench TEXT,
                    url TEXT,
                    relevance_score REAL,
                    ipc_sections TEXT,
                    timeline_events TEXT,
                    verdict_info TEXT,
                    case_metadata TEXT,
                    insights TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Search history table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS search_history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    query TEXT NOT NULL,
                    user_mode TEXT,
                    filters_applied TEXT,
                    results_count INTEGER,
                    search_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    session_id TEXT
                )
            """)
            
            # Saved cases table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS saved_cases (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    case_id INTEGER,
                    user_session TEXT,
                    tags TEXT,
                    notes TEXT,
                    saved_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (case_id) REFERENCES cases (id)
                )
            """)
            
            # Generated documents table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS generated_documents (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    document_type TEXT NOT NULL,
                    title TEXT,
                    content TEXT NOT NULL,
                    client_name TEXT,
                    matter_type TEXT,
                    jurisdiction TEXT,
                    urgency_level TEXT,
                    referenced_cases TEXT,
                    generation_parameters TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    user_session TEXT
                )
            """)
            
            # Case comparisons table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS case_comparisons (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    case1_id INTEGER,
                    case2_id INTEGER,
                    similarity_score REAL,
                    comparison_analysis TEXT,
                    comparison_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    user_session TEXT,
                    FOREIGN KEY (case1_id) REFERENCES cases (id),
                    FOREIGN KEY (case2_id) REFERENCES cases (id)
                )
            """)
            
            # User preferences table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS user_preferences (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id TEXT UNIQUE,
                    preferred_mode TEXT,
                    default_max_results INTEGER DEFAULT 20,
                    auto_save_searches BOOLEAN DEFAULT 1,
                    show_insights BOOLEAN DEFAULT 1,
                    default_export_format TEXT DEFAULT 'JSON',
                    advanced_filters_default BOOLEAN DEFAULT 0,
                    preferences_json TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # IPC sections reference table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS ipc_sections (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    section_number TEXT UNIQUE NOT NULL,
                    section_title TEXT NOT NULL,
                    description TEXT,
                    category TEXT,
                    punishment_details TEXT,
                    related_sections TEXT,
                    case_count INTEGER DEFAULT 0,
                    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Create indexes
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_cases_docid ON cases(docid)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_cases_court ON cases(court)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_search_query ON search_history(query)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_search_timestamp ON search_history(search_timestamp)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_saved_cases_session ON saved_cases(user_session)")
            
            conn.commit()
            
        self._populate_ipc_sections()
    
    def _populate_ipc_sections(self):
        """Populate IPC sections reference table"""
        ipc_data = [
            ('302', 'Murder', 'Punishment for murder', 'Offences affecting the human body', 'Death or imprisonment for life'),
            ('307', 'Attempt to murder', 'Attempt to murder', 'Offences affecting the human body', 'Imprisonment up to 10 years'),
            ('376', 'Rape', 'Rape and sexual offenses', 'Sexual offences', 'Minimum 7 years imprisonment'),
            ('420', 'Cheating', 'Cheating and dishonestly inducing delivery of property', 'Property offences', 'Imprisonment up to 7 years'),
            ('498A', 'Cruelty by husband', 'Husband or relative subjecting woman to cruelty', 'Offences relating to marriage', 'Imprisonment up to 3 years'),
            ('304', 'Culpable homicide', 'Punishment for culpable homicide not amounting to murder', 'Offences affecting the human body', 'Imprisonment for life or up to 10 years'),
            ('323', 'Voluntarily causing hurt', 'Punishment for voluntarily causing hurt', 'Offences affecting the human body', 'Imprisonment up to 1 year'),
            ('325', 'Voluntarily causing grievous hurt', 'Punishment for voluntarily causing grievous hurt', 'Offences affecting the human body', 'Imprisonment up to 7 years'),
            ('379', 'Theft', 'Punishment for theft', 'Property offences', 'Imprisonment up to 3 years'),
            ('447', 'Criminal trespass', 'Punishment for criminal trespass', 'Property offences', 'Imprisonment up to 3 months'),
            ('506', 'Criminal intimidation', 'Punishment for criminal intimidation', 'Offences against public tranquillity', 'Imprisonment up to 2 years')
        ]
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            for section_data in ipc_data:
                cursor.execute("""
                    INSERT OR IGNORE INTO ipc_sections 
                    (section_number, section_title, description, category, punishment_details)
                    VALUES (?, ?, ?, ?, ?)
                """, section_data)
            conn.commit()
    
    def save_case(self, case_data: Dict[str, Any]) -> int:
        """Save a legal case to the database"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            ipc_sections_json = json.dumps(case_data.get('ipc_sections', []))
            timeline_json = json.dumps(case_data.get('timeline', []))
            verdict_json = json.dumps(case_data.get('verdict', {}))
            metadata_json = json.dumps(case_data.get('metadata', {}))
            insights_json = json.dumps(case_data.get('insights', []))
            
            cursor.execute("""
                INSERT OR REPLACE INTO cases (
                    docid, title, summary, full_text, court, judge, petitioner, respondent,
                    date_decided, citation, bench, url, relevance_score, ipc_sections,
                    timeline_events, verdict_info, case_metadata, insights, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                case_data.get('docid', ''),
                case_data.get('title', ''),
                case_data.get('summary', ''),
                case_data.get('full_text', ''),
                case_data.get('metadata', {}).get('court', ''),
                case_data.get('metadata', {}).get('judge', ''),
                case_data.get('metadata', {}).get('petitioner', ''),
                case_data.get('metadata', {}).get('respondent', ''),
                case_data.get('metadata', {}).get('date', ''),
                case_data.get('metadata', {}).get('citation', ''),
                case_data.get('metadata', {}).get('bench', ''),
                case_data.get('metadata', {}).get('url', ''),
                case_data.get('relevance_score', 0.0),
                ipc_sections_json,
                timeline_json,
                verdict_json,
                metadata_json,
                insights_json,
                datetime.now().isoformat()
            ))
            
            case_id = cursor.lastrowid
            conn.commit()
            
            self._update_ipc_counts(case_data.get('ipc_sections', []))
            
            return case_id
    
    def _update_ipc_counts(self, ipc_sections: List[Dict]):
        """Update case counts for IPC sections"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            for section in ipc_sections:
                section_num = section.get('section', '')
                if section_num:
                    cursor.execute("""
                        UPDATE ipc_sections 
                        SET case_count = case_count + 1 
                        WHERE section_number = ?
                    """, (section_num,))
            conn.commit()
    
    def get_case_by_docid(self, docid: str) -> Optional[Dict]:
        """Retrieve a case by document ID"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM cases WHERE docid = ?", (docid,))
            row = cursor.fetchone()
            
            if row:
                return self._row_to_case_dict(row)
            return None
    
    def search_cases_in_db(self, query: str, filters: Dict = None, limit: int = 50) -> List[Dict]:
        """Search cases in the database"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            sql = "SELECT * FROM cases WHERE "
            params = []
            conditions = []
            
            if query:
                conditions.append("(title LIKE ? OR summary LIKE ? OR full_text LIKE ?)")
                query_pattern = f"%{query}%"
                params.extend([query_pattern, query_pattern, query_pattern])
            
            if filters:
                if filters.get('court'):
                    conditions.append("court LIKE ?")
                    params.append(f"%{filters['court']}%")
                
                if filters.get('judge'):
                    conditions.append("judge LIKE ?")
                    params.append(f"%{filters['judge']}%")
                
                if filters.get('ipc_section'):
                    conditions.append("ipc_sections LIKE ?")
                    params.append(f"%{filters['ipc_section']}%")
            
            if not conditions:
                conditions.append("1=1")
            
            sql += " AND ".join(conditions)
            sql += " ORDER BY relevance_score DESC, created_at DESC LIMIT ?"
            params.append(limit)
            
            cursor.execute(sql, params)
            rows = cursor.fetchall()
            
            return [self._row_to_case_dict(row) for row in rows]
    
    def _row_to_case_dict(self, row) -> Dict:
        """Convert database row to case dictionary"""
        columns = [
            'id', 'docid', 'title', 'summary', 'full_text', 'court', 'judge',
            'petitioner', 'respondent', 'date_decided', 'citation', 'bench', 'url',
            'relevance_score', 'ipc_sections', 'timeline_events', 'verdict_info',
            'case_metadata', 'insights', 'created_at', 'updated_at'
        ]
        
        case_dict = dict(zip(columns, row))
        
        try:
            case_dict['ipc_sections'] = json.loads(case_dict['ipc_sections'] or '[]')
            case_dict['timeline'] = json.loads(case_dict['timeline_events'] or '[]')
            case_dict['verdict'] = json.loads(case_dict['verdict_info'] or '{}')
            case_dict['metadata'] = json.loads(case_dict['case_metadata'] or '{}')
            case_dict['insights'] = json.loads(case_dict['insights'] or '[]')
        except json.JSONDecodeError:
            case_dict['ipc_sections'] = []
            case_dict['timeline'] = []
            case_dict['verdict'] = {}
            case_dict['metadata'] = {}
            case_dict['insights'] = []
        
        return case_dict
    
    def save_search_history(self, query: str, user_mode: str, filters: Dict = None, 
                           results_count: int = 0, session_id: str = None) -> int:
        """Save search history entry"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            filters_json = json.dumps(filters or {})
            
            cursor.execute("""
                INSERT INTO search_history (query, user_mode, filters_applied, results_count, session_id)
                VALUES (?, ?, ?, ?, ?)
            """, (query, user_mode, filters_json, results_count, session_id))
            
            search_id = cursor.lastrowid
            conn.commit()
            return search_id
    
    def get_search_history(self, session_id: str = None, limit: int = 50) -> List[Dict]:
        """Get search history"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            if session_id:
                cursor.execute("""
                    SELECT * FROM search_history 
                    WHERE session_id = ? 
                    ORDER BY search_timestamp DESC LIMIT ?
                """, (session_id, limit))
            else:
                cursor.execute("""
                    SELECT * FROM search_history 
                    ORDER BY search_timestamp DESC LIMIT ?
                """, (limit,))
            
            rows = cursor.fetchall()
            columns = ['id', 'query', 'user_mode', 'filters_applied', 'results_count', 'search_timestamp', 'session_id']
            
            history = []
            for row in rows:
                entry = dict(zip(columns, row))
                try:
                    entry['filters'] = json.loads(entry['filters_applied'] or '{}')
                except json.JSONDecodeError:
                    entry['filters'] = {}
                history.append(entry)
            
            return history
    
    def bookmark_case(self, case_id: int, user_session: str, tags: List[str] = None, notes: str = "") -> int:
        """Bookmark a case"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            tags_json = json.dumps(tags or [])
            
            cursor.execute("""
                INSERT INTO saved_cases (case_id, user_session, tags, notes)
                VALUES (?, ?, ?, ?)
            """, (case_id, user_session, tags_json, notes))
            
            bookmark_id = cursor.lastrowid
            conn.commit()
            return bookmark_id
    
    def get_bookmarked_cases(self, user_session: str) -> List[Dict]:
        """Get bookmarked cases"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            cursor.execute("""
                SELECT c.*, sc.tags, sc.notes, sc.saved_at
                FROM cases c
                JOIN saved_cases sc ON c.id = sc.case_id
                WHERE sc.user_session = ?
                ORDER BY sc.saved_at DESC
            """, (user_session,))
            
            rows = cursor.fetchall()
            bookmarked_cases = []
            
            for row in rows:
                case_dict = self._row_to_case_dict(row[:-3])
                case_dict['bookmark_tags'] = json.loads(row[-3] or '[]')
                case_dict['bookmark_notes'] = row[-2]
                case_dict['bookmarked_at'] = row[-1]
                bookmarked_cases.append(case_dict)
            
            return bookmarked_cases
    
    def save_generated_document(self, doc_data: Dict) -> int:
        """Save a generated document"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            referenced_cases_json = json.dumps(doc_data.get('referenced_cases', []))
            params_json = json.dumps(doc_data.get('generation_parameters', {}))
            
            cursor.execute("""
                INSERT INTO generated_documents (
                    document_type, title, content, client_name, matter_type,
                    jurisdiction, urgency_level, referenced_cases, generation_parameters, user_session
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                doc_data.get('document_type', ''),
                doc_data.get('title', ''),
                doc_data.get('content', ''),
                doc_data.get('client_name', ''),
                doc_data.get('matter_type', ''),
                doc_data.get('jurisdiction', ''),
                doc_data.get('urgency_level', ''),
                referenced_cases_json,
                params_json,
                doc_data.get('user_session', '')
            ))
            
            doc_id = cursor.lastrowid
            conn.commit()
            return doc_id
    
    def get_analytics_data(self, user_session: str = None) -> Dict:
        """Get analytics data"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            analytics = {}
            
            cursor.execute("SELECT COUNT(*) FROM cases")
            analytics['total_cases'] = cursor.fetchone()[0]
            
            if user_session:
                cursor.execute("SELECT COUNT(*) FROM search_history WHERE session_id = ?", (user_session,))
            else:
                cursor.execute("SELECT COUNT(*) FROM search_history")
            analytics['total_searches'] = cursor.fetchone()[0]
            
            cursor.execute("""
                SELECT section_number, section_title, case_count 
                FROM ipc_sections 
                WHERE case_count > 0
                ORDER BY case_count DESC LIMIT 10
            """)
            analytics['top_ipc_sections'] = [
                {'section': row[0], 'title': row[1], 'count': row[2]}
                for row in cursor.fetchall()
            ]
            
            cursor.execute("""
                SELECT court, COUNT(*) as count 
                FROM cases 
                WHERE court IS NOT NULL AND court != ''
                GROUP BY court 
                ORDER BY count DESC LIMIT 10
            """)
            analytics['court_distribution'] = [
                {'court': row[0], 'count': row[1]}
                for row in cursor.fetchall()
            ]
            
            return analytics
    
    def get_database_stats(self) -> Dict:
        """Get database statistics"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            stats = {}
            
            tables = ['cases', 'search_history', 'saved_cases', 'generated_documents', 'case_comparisons']
            for table in tables:
                cursor.execute(f"SELECT COUNT(*) FROM {table}")
                stats[f'{table}_count'] = cursor.fetchone()[0]
            
            db_path = Path(self.db_path)
            if db_path.exists():
                stats['database_size_mb'] = round(db_path.stat().st_size / (1024 * 1024), 2)
            
            return stats