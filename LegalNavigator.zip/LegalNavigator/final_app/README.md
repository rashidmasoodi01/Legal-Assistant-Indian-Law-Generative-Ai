# Legal Assistant Pro - Complete Application with Database Integration

A comprehensive AI-powered legal research platform with SQLite database integration, supporting multiple user modes and real-time case data from Indian courts.

## Features

### Core Functionality
- **Multi-Mode Interface**: Student, Lawyer, Judge, and General modes with tailored features
- **Real Legal Case Search**: Integration with Indian Kanoon API for authentic case data
- **AI-Powered Analysis**: Advanced case summarization and legal document generation
- **Comprehensive Database**: SQLite integration for persistent data storage
- **Dynamic Backgrounds**: Mode-specific visual themes and styling

### Database Integration
- **Case Management**: Persistent storage of legal cases with full metadata
- **Search History**: Complete tracking of user searches and results
- **Bookmarking System**: Save and organize important cases
- **Document Generation**: Store AI-generated legal documents
- **Analytics Dashboard**: Real-time insights and statistics
- **User Preferences**: Customizable settings per session

### Advanced Features
- **Hybrid Search**: Search both live API and local database
- **Case Comparison**: Side-by-side analysis of legal precedents
- **Timeline Extraction**: Automatic extraction of case chronology
- **IPC Section Analysis**: Identification and explanation of relevant sections
- **Export Capabilities**: Multiple format downloads (JSON, PDF, Text)
- **Database Management**: Backup, cleanup, and optimization tools

## Installation

1. Install required packages:
```bash
pip install -r requirements.txt
```

2. Configure environment variables in `.env`:
```
INDIANKANOON_API_TOKEN=your_indian_kanoon_token
GROQ_API_KEY=your_groq_api_key
HUGGINGFACE_API_TOKEN=your_huggingface_token
API_URL=https://api-inference.huggingface.co/models/sshleifer/distilbart-cnn-12-6
```

3. Run the application:
```bash
streamlit run main.py --server.port 5000
```

## Project Structure

```
final_app/
├── main.py                     # Main application with database integration
├── requirements.txt            # Python dependencies
├── .env                       # Environment variables
├── README.md                  # This file
├── database/
│   ├── __init__.py
│   └── legal_database.py      # SQLite database management
├── components/
│   ├── legal_api.py           # Indian Kanoon API integration
│   └── legal_utils.py         # Text processing utilities
├── assets/
│   ├── __init__.py
│   ├── images.py              # Background image management
│   └── styles.py              # Dynamic styling system
└── templates/
    └── (document templates)
```

## Database Schema

The application uses SQLite with the following main tables:

- **cases**: Legal case data with full text and metadata
- **search_history**: User search patterns and results
- **saved_cases**: Bookmarked cases per user session
- **generated_documents**: AI-generated legal documents
- **case_comparisons**: Comparative analysis records
- **user_preferences**: Customizable user settings
- **ipc_sections**: Reference data for Indian Penal Code sections

## API Integration

### Indian Kanoon API
- Real-time access to Indian court cases
- Comprehensive case metadata extraction
- Advanced search filtering capabilities

### Groq AI API
- Legal document generation
- Case analysis and insights
- Comparative case analysis

### Hugging Face API
- Automatic text summarization
- Legal text processing
- Content analysis

## User Modes

### Student Mode
- Academic research focus
- Educational case studies
- Citation formatting
- Research report generation

### Lawyer Mode
- Professional case analysis
- Strategic precedent research
- Client brief generation
- Legal argument development

### Judge Mode
- Judicial research compilation
- Precedent classification
- Legal framework analysis
- Sentencing guideline references

### General Mode
- Basic legal information
- Simple case searches
- Legal procedure guidance
- Rights information

## Database Features

### Data Persistence
- Automatic case storage from API searches
- Persistent search history across sessions
- Bookmarking and note-taking capabilities
- Generated document archival

### Analytics
- Search pattern analysis
- IPC section frequency tracking
- Court-wise case distribution
- User activity monitoring

### Management Tools
- Database backup functionality
- Old data cleanup utilities
- Performance optimization
- Size monitoring

## Usage Examples

### Searching Cases
1. Select user mode (Student/Lawyer/Judge/General)
2. Enter search query or use suggestions
3. Apply filters (court, judge, IPC section, date range)
4. Choose search scope (API, Database, or Both)
5. Review results with AI-powered insights

### Document Generation
1. Navigate to Document Generator
2. Select document type and enter requirements
3. Configure advanced options
4. Generate using AI with database case references
5. Download in multiple formats

### Case Analysis
1. Search and select cases for comparison
2. Add to comparison queue (up to 2 cases)
3. Generate AI-powered comparative analysis
4. Save results to database

### Library Management
1. Bookmark important cases during research
2. Add personal notes and tags
3. View search history and patterns
4. Export collections in various formats

## Technical Specifications

- **Backend**: Python with Streamlit
- **Database**: SQLite with full ACID compliance
- **APIs**: REST integration with proper error handling
- **Caching**: Intelligent caching for performance
- **Security**: Environment variable configuration
- **Scalability**: Modular architecture for easy expansion

## Performance Features

- **Caching System**: Reduces API calls and improves response times
- **Database Indexing**: Optimized queries for fast search
- **Progress Indicators**: Real-time feedback during operations
- **Error Handling**: Comprehensive error management
- **Session Management**: Persistent user sessions

## Deployment

The application is designed for easy deployment on cloud platforms:

1. **Local Development**: Direct Python execution
2. **Cloud Deployment**: Compatible with major cloud providers
3. **Docker Support**: Containerization ready
4. **Environment Configuration**: Flexible setup options

## Support and Maintenance

### Database Maintenance
- Regular backup scheduling
- Performance monitoring
- Data integrity checks
- Cleanup automation

### API Management
- Rate limiting compliance
- Error recovery mechanisms
- Fallback strategies
- Status monitoring

## Legal Compliance

- Uses authentic legal data from authorized sources
- Maintains data integrity throughout processing
- Provides proper attribution for case sources
- Implements responsible AI usage guidelines

## Contributing

The modular architecture supports easy extension:

1. **New User Modes**: Add mode configurations
2. **Additional APIs**: Integrate new data sources
3. **Enhanced Analytics**: Expand database insights
4. **Document Types**: Add new generation templates

## License

This application is designed for educational and professional legal research purposes. Ensure compliance with API terms of service and local regulations.