import streamlit as st

class ImageManager:
    """Manages background image display (currently disabled for plain styling)"""

    def display_background(self, mode: str):
        """
        Background images are intentionally disabled to use plain color themes
        set by the StyleManager. If needed, you can re-enable this by setting
        URLs per mode and injecting them with custom CSS.
        """
        pass
