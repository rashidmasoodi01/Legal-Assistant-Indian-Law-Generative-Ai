import streamlit as st

class StyleManager:
    """Manage dynamic styling and themes for different user modes"""

    def __init__(self):
        self.mode_themes = {
            "Student": {
                "primary_color": "#1e3a8a",
                "background_color": "#fcfcfc",
                "text_color": "#1f2937",
                "accent_color": "#99baed"
            },
            "Lawyer": {
                "primary_color": "#166534",
                "background_color": "#f0f0f0",
                "text_color": "#1f2937",
                "accent_color": "#10b981"
            },
            "Judge": {
                "primary_color": "#991b1b",
                "background_color": "#f5f5f5",
                "text_color": "#1f2937",
                "accent_color": "#ef4444"
            },
            "General": {
                "primary_color": "#4cb470",
                "background_color": "#ffffff",
                "text_color": "#1f2937",
                "accent_color": "#6366f1"
            }
        }

    def apply_mode_styling(self, mode: str):
        """Apply plain white/grey styling based on current user mode"""
        theme = self.mode_themes.get(mode, self.mode_themes["General"])

        custom_css = f"""
        <style>
        .stApp {{
            background-color: {theme["background_color"]} !important;
        }}

        .main .block-container {{
            background: #ffffff;
            border-radius: 12px;
            padding: 2rem;
            margin: 1rem;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
        }}

        .stSelectbox > div > div,
        .stTextInput > div > div {{
            background-color: #ffffff;
            border-radius: 6px;
            border: 1px solid #e0e0e0;
        }}

        .stButton > button {{
            background: {theme["primary_color"]};
            color: white;
            border-radius: 6px;
            border: none;
            padding: 0.5rem 1rem;
            transition: background 0.3s ease;
        }}

        .stButton > button:hover {{
            background: {theme["accent_color"]};
        }}

        .metric-card {{
            background: #ffffff;
            padding: 1rem;
            border-radius: 8px;
            border-left: 4px solid {theme["primary_color"]};
            margin: 0.5rem 0;
        }}

        .mode-badge {{
            background: {theme["primary_color"]};
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-weight: bold;
            text-align: center;
            margin: 1rem 0;
        }}
        </style>
        """

        st.markdown(custom_css, unsafe_allow_html=True)

    def get_mode_color(self, mode: str) -> str:
        """Get primary color for a mode"""
        return self.mode_themes.get(mode, self.mode_themes["General"])["primary_color"]
